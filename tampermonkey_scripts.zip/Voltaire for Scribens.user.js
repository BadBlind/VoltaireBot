// ==UserScript==
// @name         Voltaire for Scribens
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.scribens.fr/?vartext=*
// @grant        none
// @require http://code.jquery.com/jquery-latest.js
// ==/UserScript==

(function() {
    function $_GET(param) {
	var vars = {};
	window.location.href.replace( location.hash, '' ).replace( 
		/[?&]+([^=&]+)=?([^&]*)?/gi, // regexp
		function( m, key, value ) { // callback
			vars[key] = value !== undefined ? value : '';
		}
	);

	if ( param ) {
		return vars[param] ? vars[param] : null;	
	}
	return vars;
}
    $('header').css('display', 'none');
    var text = decodeURI($_GET('vartext'));
    $('#FrameTx').contents().find('p').html(text);
    $('#check').trigger('click');
    // Your code here...
})();