// ==UserScript==
// @name         Voltaire
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.projet-voltaire.fr/*
// @grant        none
// @require http://code.jquery.com/jquery-latest.js
// ==/UserScript==

(function() {
    'use strict';

    var text = $('.sentenceClickView').text();
    $('#appFooter').html('<iframe height="1000" id="frame_scrib" src="https://www.scribens.fr/?vartext=' + encodeURI(text) + '" ></iframe>');
    $('#frame_scrib').css('display', 'block');
    $('#frame_scrib').css('width', '1000px');
})();